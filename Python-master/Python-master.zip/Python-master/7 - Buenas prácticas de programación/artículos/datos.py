from typing import Any


artículos: dict[str, dict[int, dict[str, Any]]]
artículos = {"artículo": {}}
