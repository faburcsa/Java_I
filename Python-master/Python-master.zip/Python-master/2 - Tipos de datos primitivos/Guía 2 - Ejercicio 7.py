expresion_1 = False == True
expresion_2 = 10 >= 2 * 4
expresion_3 = 33 / 3 == 11
expresion_4 = True > False
expresion_5 = True * 5 == 2.5 * 2

expresiones = (expresion_1, expresion_2, expresion_3, expresion_4, expresion_5)
print(expresiones)