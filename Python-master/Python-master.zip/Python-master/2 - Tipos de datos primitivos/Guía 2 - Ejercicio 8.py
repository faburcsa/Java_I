expresion_1 = not False
expresion_2 = not 3 == 5
expresion_3 = 33/3 == 11 and 5 > 2
expresion_4 = True or False
expresion_5 = True*5 == 2.5*2 or 123 >= 23
expresion_6 = 12 > 7 and True < False

expresiones = (
    expresion_1,
    expresion_2,
    expresion_3,
    expresion_4,
    expresion_5,
    expresion_6
)
print(expresiones)