lista_1 = ["h", "o", "l", "a", " ", "m", "u", "n", "d", "o"]
lista_2 = ["h", "o", "l", "a", " ", "l", "u", "n", "a"]

interseccion = set(lista_1) & set(lista_2)
lista_3 = list(interseccion)

print(lista_3)